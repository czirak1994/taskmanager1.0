from django.contrib import admin
from .models import TaskGroup, TaskTitle

admin.site.register(TaskGroup)
admin.site.register(TaskTitle)

# Register your models here.
